$(document).ready(function(){
    $(".nav_icon").click(function(){
        $(".nav_icon").toggleClass("active")
    });
    $(".nav_icon").click(function(){
        $(".navmenu").toggleClass("active")
    });
})